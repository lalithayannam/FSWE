# SocialConnect — Instagram-inspired full-stack social app

An upgraded version of your original React + Express + MongoDB project. It keeps your existing stack and builds a more polished social-feed experience inspired by common social-network patterns (not an official Instagram clone).

## What's upgraded

- **Modern responsive UI:** gradient branding, polished authentication, responsive three-column feed, mobile navigation, story-style discovery strip, and empty/loading/error feedback.
- **Authentication:** registration/login with hashed passwords and JWT authentication.
- **Posts:** text, image, and video posts; media-only posts work; character count; timestamps; newest-first feed.
- **Engagement:** like/unlike, comments, comment counts, and saved posts.
- **Feed modes:** For You (all posts), Following (posts by accounts you follow plus your own posts), and Saved (your private saved-post collection).
- **People search and following:** search by name/username and follow/unfollow accounts.
- **Direct messages:** persistent one-to-one text conversations, conversation list, unread indicators, and message polling for near-real-time updates.
- **Voice/video calls:** browser microphone/camera calling with WebRTC, incoming call invitations, accept/decline, hang up, and recent call history. Both participants should be online; network/firewall conditions can affect peer-to-peer calls.
- **Profile editing:** update display name and bio, upload a profile picture, and use the saved avatar across the interface.
- **Post ownership:** users can delete their own posts; other users cannot delete them. Deleted posts are removed from saved-post lists.
- **API configuration:** frontend API/media base URLs can be configured using environment variables.
- **Upload validation:** JPG, PNG, GIF, WEBP, MP4, WEBM, MOV, OGG; 50 MB maximum per file.

## Requirements

- Node.js 18 or newer (20 LTS recommended)
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- npm

## Run on Windows (PowerShell)

### 1. Start MongoDB

Make sure your local MongoDB service is running, or create a MongoDB Atlas database and copy its connection string.

### 2. Configure and start the backend

Open PowerShell in the project folder:

```powershell
cd backend
Copy-Item .env.example .env
```

Open `backend/.env` and replace `JWT_SECRET` with a long random secret. Set `MONGODB_URI` to your local MongoDB URL or Atlas URI. Then run:

```powershell
npm install
npm run dev
```

The API example is configured for `http://localhost:5002`. Check `http://localhost:5002/api/health`. If port 5002 is occupied, choose a free port in `backend/.env` and update both URLs in `frontend/.env` to match.

### 3. Start the frontend in a second terminal

From the project root:

```powershell
cd frontend
Copy-Item .env.example .env
npm install
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

Keep both terminals running. Register an account to start using the app. Register a second account in another browser/incognito window to test following, feed filtering, likes, comments, and saved posts.

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create an account |
| POST | `/api/auth/login` | Log in |
| GET | `/api/posts` | Get all posts (requires JWT) |
| GET | `/api/posts?feed=following` | Feed from followed accounts and yourself |
| GET | `/api/posts?feed=saved` | Current user's saved posts |
| POST | `/api/posts` | Create a text/media post |
| POST | `/api/posts/:id/like` | Like/unlike a post |
| POST | `/api/posts/:id/comments` | Add a comment |
| POST | `/api/posts/:id/save` | Save/unsave a post |
| DELETE | `/api/posts/:id` | Delete your own post |
| GET | `/api/users/search?q=...` | Search users |
| GET | `/api/users/me` | Get your authenticated profile |
| PATCH | `/api/users/me` | Update profile name, bio, and avatar (`multipart/form-data`) |
| GET | `/api/messages/conversations` | List recent conversations |
| GET | `/api/messages/:userId` | Read a conversation |
| POST | `/api/messages/:userId` | Send a direct message |
| GET | `/api/calls/active` | List active calls and incoming invitations |
| GET | `/api/calls/history` | Recent completed calls |
| POST | `/api/calls/:userId` | Start a voice or video call (`{ "type": "audio" }` or `{ "type": "video" }`) |
| GET | `/api/calls/session/:id` | Get call state/signals |
| POST | `/api/calls/session/:id/signal` | Exchange WebRTC offer/answer/ICE or end/reject a call |
| POST | `/api/users/:id/follow` | Follow/unfollow a user |
| GET | `/api/users/:username` | Get a public profile and posts |

## Project structure

```text
SocialConnect/
├── backend/
│   ├── uploads/
│   └── src/
│       ├── controllers/
│       ├── middleware/
│       ├── models/
│       ├── routes/
│       └── server.js
└── frontend/
    └── src/
        ├── services/api.js
        ├── App.jsx
        ├── main.jsx
        └── styles.css
```

## Important notes / next steps

- Local file uploads are for development and demo use. For production, use object storage such as Cloudinary or Amazon S3, plus image/video processing and moderation.
- This is an educational project, not production-ready social infrastructure. Before public deployment, add rate limiting, stronger input validation, secure cookie-based refresh-token handling, account recovery, email verification, privacy controls, logging, and automated tests. Configure CORS to allow only your deployed frontend domain.
- The story strip is a visual discovery placeholder, not a persistent 24-hour Stories feature. The story strip remains a visual discovery placeholder. Calling uses browser WebRTC and a simple database-backed polling signal channel; production use should add a TURN server, stronger call lifecycle cleanup, WebSocket signaling, and abuse controls. Message delivery updates by polling rather than a dedicated WebSocket connection.
- If you previously created an account, it should continue working with the existing database. New `savedPosts` fields are initialized by Mongoose defaults.
